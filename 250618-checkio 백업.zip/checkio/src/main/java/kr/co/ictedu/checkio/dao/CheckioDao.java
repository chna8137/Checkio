package kr.co.ictedu.checkio.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public class CheckioDao {
	
	

}
