package kr.co.ictedu.checkio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckioApplicationTests {

	@Test
	void contextLoads() {
	}

}
